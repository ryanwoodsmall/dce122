...\" @OSF_COPYRIGHT@
...\" COPYRIGHT NOTICE
...\" Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
...\" ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
...\" the full copyright text.
...\" 
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.2.3  1994/06/13  16:33:21  devobj
...\" 	cr10872 - fix copyright
...\" 	[1994/06/13  16:32:44  devobj]
...\"
...\" Revision 1.1.2.2  1994/05/05  19:45:38  jeff
...\" 	{defect, 10527, R1.1}
...\" 	Create structure for new DFS documentation organization.
...\" 	(Remove closing quotes.)
...\" 	[1994/05/05  19:43:21  jeff]
...\" 
...\" Revision 1.1.2.1  1994/05/04  20:26:29  jeff
...\" 	{defect, 10527, R1.1}
...\" 	Create structure for new DFS documentation organization.
...\" 	[1994/05/04  20:26:00  jeff]
...\" 
...\" $EndLog$
...\"
.ds !@ OSF DCE DFS Administration Guide and Reference
...\"
