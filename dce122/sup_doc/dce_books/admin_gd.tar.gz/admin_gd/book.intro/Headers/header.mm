...\"
...\" @OSF_COPYRIGHT@
...\" COPYRIGHT NOTICE
...\" Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
...\" ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
...\" src directory for the full copyright text.
...\"
...\"
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.4.2  1993/05/17  15:07:37  buckler
...\" 	Closed up em dash in book title per Prentice-Hall editorial review.
...\" 	[1993/05/06  15:32:29  buckler]
...\"
...\" Revision 1.1.2.4  1993/01/28  19:04:38  dbelch
...\" 	Embedding copyright notice
...\" 	[1993/01/28  18:28:16  dbelch]
...\" 
...\" Revision 1.1.2.3  1993/01/27  20:23:28  steiner
...\" 	Dash not colon in title.
...\" 	[1993/01/27  20:21:10  steiner]
...\" 
...\" Revision 1.1.2.2  1993/01/21  22:06:11  steiner
...\" 	Header file
...\" 	[1993/01/21  22:03:13  steiner]
...\" 
...\" 	initial header.mm file
...\" 	[1992/12/03  21:30:31  steiner]
...\" 
...\" $EndLog$
...\"
.ds !@ OSF DCE Administration Guide\*(EMIntroduction\"
