...\"
...\" @OSF_COPYRIGHT@
...\" COPYRIGHT NOTICE
...\" Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
...\" ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
...\" src directory for the full copyright text.
...\"
...\"
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.4.2  1993/06/01  18:15:09  buckler
...\" 	{edit, R1.0.2}
...\" 	Eliminated spaces around em-dash in book title.
...\" 	[1993/05/17  15:24:04  buckler]
...\"
...\" Revision 1.1.2.4  1993/01/28  19:04:22  dbelch
...\" 	Embedding copyright notice
...\" 	[1993/01/28  18:27:50  dbelch]
...\" 
...\" Revision 1.1.2.3  1993/01/27  20:23:34  steiner
...\" 	Dash not colon in title.
...\" 	[1993/01/27  20:19:48  steiner]
...\" 
...\" Revision 1.1.2.2  1993/01/21  22:05:41  steiner
...\" 	header.mm file for Core Components book of Admin Gd
...\" 	[1993/01/21  22:00:46  steiner]
...\" 
...\" $EndLog$
...\"
.ds !@ OSF DCE Administration Guide\*(EMCore Components\"
