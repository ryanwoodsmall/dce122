...\"
...\"  @OSF_COPYRIGHT@
...\"  COPYRIGHT NOTICE
...\"  Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
...\"  ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
...\"  src directory for the full copyright text.
...\"
...\"
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.4.4  1994/04/01  19:56:22  rom
...\" 	{enh, 10269, R1.1}
...\" 	Rename Administration Reference to Command Reference.
...\" 	[1994/04/01  19:12:30  rom]
...\"
...\" Revision 1.1.4.3  1993/01/28  01:44:01  dbelch
...\" 	Embedding copyright notice
...\" 	[1993/01/28  00:39:35  dbelch]
...\" 
...\" Revision 1.1.4.2  1992/09/09  18:37:03  weir
...\" 	Moved to 1.0.2doc tree
...\" 	[1992/09/09  18:36:24  weir]
...\" 
...\" Revision 1.1.2.3  1992/09/09  18:27:32  weir
...\" 	Moved into 1.0.2doc tree
...\" 	[1992/09/09  18:26:53  weir]
...\" 
...\" Revision 1.1.2.2  1992/09/08  17:39:01  casey
...\" 	Prentice Hall production
...\" 	[1992/09/08  16:19:05  casey]
...\" 
...\" Revision 1.1  1992/01/29  15:44:18  damon
...\" 	Initial revision
...\" 
...\" $EndLog$
...\"
...\" Copyright (c) 1991, Open Software Foundation, Inc. ALL RIGHTS RESERVED
...\"
...\"	local header file
...\"
...\"
...\"
...\"
.ds !@ OSF DCE Command Reference\"
...\"
...\"
...\"
