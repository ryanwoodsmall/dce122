...\" @OSF_COPYRIGHT@
...\" COPYRIGHT NOTICE
...\" Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
...\" ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
...\" the full copyright text.
...\" 
...\" 
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.2.2  1994/06/13  16:15:19  devobj
...\" 	cr10872 - fix copyright
...\" 	[1994/06/13  16:08:48  devobj]
...\"
...\" Revision 1.1.2.1  1994/02/11  17:58:11  rom
...\" 	First version.
...\" 	[1994/02/11  15:01:27  rom]
...\" 
...\" $EndLog$
...\"
...\"	local header file
...\"
...\"
...\"
...\"
.ds !@ OSF DCE Problem Determination Guide\"
...\"
...\"
...\"
