...\"
...\" @OSF_COPYRIGHT@
...\" COPYRIGHT NOTICE
...\" Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
...\" ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
...\" src directory for the full copyright text.
...\"
...\"
...\" HISTORY
...\" $Log: 3o_example_10.h,v $
...\" Revision 1.1.4.3  1993/01/29  17:19:34  cjd
...\" 	Embedded copyright notice
...\" 	[1993/01/29  17:03:29  cjd]
...\"
...\" Revision 1.1.4.2  1992/09/01  16:32:02  weir
...\" 	Moved
...\" 	[1992/09/01  16:23:53  weir]
...\" 
...\" Revision 1.1.2.2  1992/03/06  16:33:57  steiner
...\" 	replaced comment leader
...\" 	[1992/03/06  15:49:53  steiner]
...\" 
...\" Revision 1.1  1992/01/29  15:41:01  damon
...\" 	Initial revision
...\" 
...\" $EndLog$
...\"
/*
 * DCE Program Example Using DFS
 *
 * dfs_greet.h
 */

#define C_GREET_FILE "/.../my_cell/fs/opt/my_company/greet/client"
#define S_GREET_FILE "/.../my_cell/fs/opt/my_company/greet/server"
