...\"
...\"  @OSF_COPYRIGHT@
...\"  COPYRIGHT NOTICE
...\"  Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
...\"  ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
...\"  src directory for the full copyright text.
...\"
...\"
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.4.3  1993/01/29  17:17:10  cjd
...\" 	Embedded copyright notice
...\" 	[1993/01/29  17:00:31  cjd]
...\"
...\" Revision 1.1.4.2  1992/09/01  14:24:55  weir
...\" 	Moved
...\" 	[1992/09/01  14:14:36  weir]
...\" 
...\" Revision 1.1.2.2  1992/03/06  16:29:17  steiner
...\" 	Added "OSF" to the title.
...\" 	[1992/03/05  22:50:42  steiner]
...\" 
...\" Revision 1.1  1992/01/29  15:40:16  damon
...\" 	Initial revision
...\" 
...\" $EndLog$
...\"
...\" (c) Copyright 1991, Open Software Foundation, Inc. ALL RIGHTS RESERVED
...\"
...\"	local header file
...\"
...\"
...\"
...\"
.ds !@ Introduction to OSF DCE\"
...\"
...\"
...\"
