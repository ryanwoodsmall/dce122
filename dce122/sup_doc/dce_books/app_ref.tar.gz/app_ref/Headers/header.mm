...\"
...\"  @OSF_COPYRIGHT@
...\"  COPYRIGHT NOTICE
...\"  Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
...\"  ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
...\"  src directory for the full copyright text.
...\"
...\"
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.6.3  1993/01/26  16:02:04  cjd
...\" 	Embedded copyright notice
...\" 	[1993/01/26  15:30:49  cjd]
...\"
...\" Revision 1.1.6.2  1992/09/30  19:36:50  weir
...\" 	Moved into 1.0.2doc tree
...\" 	[1992/09/30  19:36:02  weir]
...\" 
...\" Revision 1.1.4.2  1992/07/28  20:14:17  oaf
...\" 	Just yanking into dce1.0.1PHdoc.
...\" 	[1992/07/28  20:13:42  oaf]
...\" 
...\" Revision 1.1.2.3  1992/06/16  18:01:34  buckler
...\" 	Added OSF to book title
...\" 	[1992/06/16  18:01:02  buckler]
...\" 
...\" Revision 1.1.2.2  1992/05/11  18:10:58  marty
...\" 	Null delta, debugging backing tree
...\" 	[1992/05/11  18:10:33  marty]
...\" 
...\" Revision 1.1  1992/01/29  15:27:52  damon
...\" 	Initial revision
...\" 
...\" $EndLog$
...\"
...\" Copyright (c) 1991, Open Software Foundation, Inc. ALL RIGHTS RESERVED
...\"
...\"	local header file
...\"
...\"
...\"
...\"
.ds !@ OSF DCE Application Development Reference\"
...\"
...\"
...\"
