...\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
...\" Cambridge, Massachusetts
...\" All rights reserved.
...\"
...\" @OSF_FREE_COPYRIGHT@
...\" 
...\" HISTORY
...\" $Log: index-post.mm,v $
...\" Revision 1.1.2.5  1994/06/24  15:48:21  fred
...\" 	free copyright
...\" 	[1994/06/24  15:38:29  fred]
...\"
...\" Revision 1.1.2.4  1994/06/23  18:41:31  fred
...\" 	free copyright
...\" 	[1994/06/22  20:09:01  fred]
...\" 
...\" Revision 1.1.2.3  1993/04/10  00:37:51  bowe
...\" 	Add OSF copyright.
...\" 	[1993/04/10  00:32:45  bowe]
...\" 
...\" Revision 1.1.2.2  1992/07/06  20:15:07  bowe
...\" 	Initial rev.
...\" 	[1992/07/06  20:06:47  bowe]
...\" 
...\" $EndLog$
...\"
...\" $Header: /u1/rcs/dte/macros/index-post.mm,v 1.1.2.5 1994/06/24 15:48:21 fred Exp $
...\"
...\"  index-post.mm --	index formatting macros
...\"
...\"     this simply restores one column text
.br
.1C
