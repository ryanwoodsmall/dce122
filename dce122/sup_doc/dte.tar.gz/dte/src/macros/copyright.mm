...\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
...\" Cambridge, Massachusetts
...\" All rights reserved.
...\"
...\" @OSF_FREE_COPYRIGHT@
...\" 
...\" HISTORY
...\" $Log: copyright.mm,v $
...\" Revision 1.1.2.5  1994/06/24  15:47:58  fred
...\" 	free copyright
...\" 	[1994/06/24  15:37:46  fred]
...\"
...\" Revision 1.1.2.4  1994/06/23  18:41:05  fred
...\" 	free copyright
...\" 	[1994/06/22  20:07:07  fred]
...\" 
...\" Revision 1.1.2.3  1993/04/10  00:37:33  bowe
...\" 	Add OSF copyright.
...\" 	[1993/04/10  00:32:14  bowe]
...\" 
...\" Revision 1.1.2.2  1992/07/06  20:14:37  bowe
...\" 	Initial rev.
...\" 	[1992/07/06  20:05:52  bowe]
...\" 
...\" $EndLog$
...\"
...\" $Header: /u1/rcs/dte/macros/copyright.mm,v 1.1.2.5 1994/06/24 15:47:58 fred Exp $
...\"
...\"     copyright.mm
...\"
.BS
\\*(@C
.BE
.ds @C (c) Copyright 1991,1992,1993,1994 Open Software Foundation, Inc.
.am )f
.BS
.BE
..
