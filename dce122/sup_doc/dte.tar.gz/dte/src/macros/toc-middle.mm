...\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
...\" Cambridge, Massachusetts
...\" All rights reserved.
...\"
...\" @OSF_FREE_COPYRIGHT@
...\" 
...\" HISTORY
...\" $Log: toc-middle.mm,v $
...\" Revision 1.1.2.5  1994/06/24  15:49:04  fred
...\" 	free copyright
...\" 	[1994/06/24  15:40:26  fred]
...\"
...\" Revision 1.1.2.4  1994/06/23  18:42:14  fred
...\" 	free copyright
...\" 	[1994/06/22  20:12:14  fred]
...\" 
...\" Revision 1.1.2.3  1993/04/10  00:38:23  bowe
...\" 	Add OSF copyright.
...\" 	[1993/04/10  00:33:41  bowe]
...\" 
...\" Revision 1.1.2.2  1992/07/06  20:17:24  bowe
...\" 	Initial rev.
...\" 	[1992/07/06  20:09:20  bowe]
...\" 
...\" $EndLog$
...\"
...\" $Header: /u1/rcs/dte/macros/toc-middle.mm,v 1.1.2.5 1994/06/24 15:49:04 fred Exp $
...\"
...\"	toc-middle.mm  --  generate the table of contents.
...\"
...\"	close the definition started in tocmac1.mm:
..
...\"
...\"	now, start a definition for tables and figures:
...\"
.de >L
