...\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
...\" Cambridge, Massachusetts
...\" All rights reserved.
...\"
...\" @OSF_FREE_COPYRIGHT@
...\" 
...\" HISTORY
...\" $Log: glosshead.mm,v $
...\" Revision 1.1.2.5  1994/06/24  15:48:13  fred
...\" 	free copyright
...\" 	[1994/06/24  15:38:15  fred]
...\"
...\" Revision 1.1.2.4  1994/06/23  18:41:23  fred
...\" 	free copyright
...\" 	[1994/06/22  20:08:27  fred]
...\" 
...\" Revision 1.1.2.3  1993/04/10  00:37:45  bowe
...\" 	Add OSF copyright.
...\" 	[1993/04/10  00:32:35  bowe]
...\" 
...\" Revision 1.1.2.2  1992/07/06  20:14:52  bowe
...\" 	Initial rev.
...\" 	[1992/07/06  20:06:11  bowe]
...\" 
...\" $EndLog$
...\"
...\" $Header: /u1/rcs/dte/macros/glosshead.mm,v 1.1.2.5 1994/06/24 15:48:13 fred Exp $
...\"
...\"	glosshead.mm -- glossary title page stuff
...\"
...\"	to be used by format-glossary with glossary.mm
...\"
.H 1 "Glossary"
...\"
