...\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
...\" Cambridge, Massachusetts
...\" All rights reserved.
...\"
...\"  @OSF_FREE_COPYRIGHT@
...\"
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.2.5  1994/06/24  15:15:56  fred
...\" 	free copyright
...\" 	[1994/06/23  20:20:02  fred]
...\"
...\" Revision 1.1.2.4  1994/06/23  18:39:54  fred
...\" 	free copyright
...\" 	[1994/06/22  19:13:56  fred]
...\" 
...\" Revision 1.1.2.3  1993/04/10  01:13:17  bowe
...\" 	Add OSF copyright.
...\" 	[1993/04/10  01:13:01  bowe]
...\" 
...\" Revision 1.1.2.2  1992/05/28  17:55:57  bowe
...\" 	Initial submission.
...\" 	[1992/05/28  16:53:37  bowe]
...\" 
...\" $EndLog$
...\" _________________________________________________________________
...\"
.ds !@ DTE User's Guide/Reference\"
