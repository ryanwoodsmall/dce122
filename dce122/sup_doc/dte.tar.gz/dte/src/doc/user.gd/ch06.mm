...\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
...\" Cambridge, Massachusetts
...\" All rights reserved.
...\"
...\"  @OSF_FREE_COPYRIGHT@
...\"
...\" HISTORY
...\" $Log: ch06.mm,v $
...\" Revision 1.1.2.7  1994/06/24  15:16:34  fred
...\" 	free copyright
...\" 	[1994/06/23  20:16:04  fred]
...\"
...\" Revision 1.1.2.6  1994/06/23  18:40:32  fred
...\" 	free copyright
...\" 	[1994/06/22  19:35:15  fred]
...\" 
...\" Revision 1.1.2.5  1993/04/10  01:22:57  bowe
...\" 	Add OSF copyright.
...\" 	[1993/04/10  01:20:43  bowe]
...\" 
...\" Revision 1.1.2.4  1992/05/28  18:20:56  bowe
...\" 	Fix botched initial check-in.
...\" 	[1992/05/28  18:17:01  bowe]
...\" 
...\" Revision 1.1.2.3  1992/05/28  17:56:32  bowe
...\" 	Initial submission.
...\" 	[1992/05/28  16:53:37  bowe]
...\" 
...\" Revision 1.1.2.2  1992/05/28  16:50:29  bowe
...\" 	Initial submission.
...\" 	[1992/05/28  16:47:59  bowe]
...\" 
...\" $EndLog$
...\" _________________________________________________________________
...\"
.iX "index entry"
.iX "another index entry"
.P
This chapter provides reference pages for parts of the
DTE.  The chapter includes references for:
.BL
.LI
book-format
.LI
dmm
.LI
dman
.LI
the Description file format
.LI
the Glossary file format
.LE 
