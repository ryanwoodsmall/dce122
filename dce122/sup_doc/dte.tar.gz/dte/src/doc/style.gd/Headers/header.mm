.\" Copyright 1991,1992,1993 Open Software Foundation, Inc.,
.\" Cambridge, Massachusetts
.\" All rights reserved.
.\"
.\" @OSF_FREE_COPYRIGHT@
.\"
.\" HISTORY
.\" $Log: header.mm,v $
.\" Revision 1.1.2.5  1994/06/24  15:14:35  fred
.\" 	free copyright
.\" 	[1994/06/24  15:10:59  fred]
.\"
.\" Revision 1.1.2.4  1994/06/23  18:38:26  fred
.\" 	free copyright
.\" 	[1994/06/22  18:44:11  fred]
.\" 
.\" Revision 1.1.2.3  1993/04/10  01:26:13  bowe
.\" 	Add OSF copyright.
.\" 	[1993/04/10  01:26:01  bowe]
.\" 
.\" Revision 1.1.2.2  1992/05/28  20:03:08  bowe
.\" 	Initial revision.
.\" 	[1992/05/28  19:50:46  bowe]
.\" 
.\" $EndLog$
.\"
.ds !@ OSF Style Guide\"
