...\" @OSF_COPYRIGHT@
...\" COPYRIGHT NOTICE
...\" Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
...\" ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
...\" the full copyright text.
...\" 
...\" 
...\" HISTORY
...\" $Log: header.mm,v $
...\" Revision 1.1.2.2  1994/06/10  21:07:57  devobj
...\" 	cr10872 - fixed copyright
...\" 	[1994/06/10  20:47:39  devobj]
...\"
...\" Revision 1.1.2.1  1994/04/05  15:14:02  rom
...\" 	{enh, 10283, R1.1}
...\" 	Move DFS Application Development Guide and Reference material
...\" 	from dce_books/app_ref to supp_docs/redistrib/dfs_app_gdref.
...\" 	[1994/04/05  14:35:19  rom]
...\" 
...\" $EndLog$
...\"
...\" Copyright (c) 1991, Open Software Foundation, Inc. ALL RIGHTS RESERVED
...\"
...\"	local header file
...\"
...\"
...\"
...\"
.ds !@ OSF DCE DFS Application Development Guide and Reference\"
...\"
...\"
...\"
