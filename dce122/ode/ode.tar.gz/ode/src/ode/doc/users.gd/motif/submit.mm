.\" @OSF_FREE_COPYRIGHT@
.\" COPYRIGHT NOTICE
.\" (c) Copyright 1992, 1991, 1990 OPEN SOFTWARE FOUNDATION, INC. 
.\" ALL RIGHTS RESERVED 
.\" 
.\" HISTORY
.\" $Log: submit.mm,v $
.\" Revision 1.1.2.3  1992/12/03  19:12:48  damon
.\" 	ODE 2.2 CR 346. Expanded copyright
.\" 	[1992/12/03  18:42:36  damon]
.\"
.\" Revision 1.1.2.2  1992/03/10  23:18:01  hester
.\" 	refer to common dug
.\" 	[1992/03/10  23:06:29  hester]
.\" 
.\" $EndLog$
.\"*********************************************************************
.\"          Set page information
.\"*********************************************************************
.OH "'\fB\s10ODE User\'s Guide for Motif\fR''\\\\nP\s0'"        \"*** Set even page footers
.EH "'\s10\\\\nP''\fBSubmitting\s0\fR'"       \"*** Set odd page footers
.SK
.\"*********************************************************************
.\"          Contents of Motif DUG: Submitting 
.\"*********************************************************************
.H 1 "Submitting"
There is no significant difference between the submission process
as explained in the common DUG and as used in the Motif project.
There are no Motif specifics which need to be discussed in this chapter.
