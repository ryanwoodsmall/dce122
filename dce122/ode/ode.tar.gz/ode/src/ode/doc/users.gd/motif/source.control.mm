.\" @OSF_FREE_COPYRIGHT@
.\" COPYRIGHT NOTICE
.\" (c) Copyright 1992, 1991, 1990 OPEN SOFTWARE FOUNDATION, INC. 
.\" ALL RIGHTS RESERVED 
.\" 
.\" HISTORY
.\" $Log: source.control.mm,v $
.\" Revision 1.1.2.3  1992/12/03  19:12:46  damon
.\" 	ODE 2.2 CR 346. Expanded copyright
.\" 	[1992/12/03  18:42:33  damon]
.\"
.\" Revision 1.1.2.2  1992/03/10  23:17:56  hester
.\" 	fixed header again, took out chapter number
.\" 	[1992/03/10  22:59:43  hester]
.\" 
.\" 	fixed chapter number in header
.\" 	[1992/03/10  22:56:44  hester]
.\" 
.\" 	first cut, basically refer to common dug
.\" 	[1992/03/10  22:50:34  hester]
.\" 
.\" $EndLog$
...\"*********************************************************************
...\"          Set page information
...\"*********************************************************************
.OH "'\fB\s10ODE User\'s Guide for Motif\fR''\\\\nP\s0'"        \"*** Set even page footers
.EH "'\s10\\\\nP''\fBSource Control\s0\fR'"       \"*** Set odd page footers
.SK
...\"*********************************************************************
...\"          Contents of Motif DUG: Source Management
...\"*********************************************************************
.H 1 "Source Management"
There is no significant difference between the source control as explained
in the common DUG and as used in the Motif project.
There are no Motif specifics which need to be discussed in this chapter.
