/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * @DEC_COPYRIGHT@
 * 
 */
/*
 * HISTORY
 * $Log: idlcom.h,v $
 * Revision 1.1.2.2  1996/03/09  20:45:05  marty
 * 	Add OSF copyright
 * 	[1996/03/09  20:24:44  marty]
 *
 * Revision 1.1.2.1  1995/12/08  00:13:11  root
 * 	Submit OSF/DCE 1.2.1
 * 
 * 	HP revision /main/dat_xidl2/1  1995/11/17  17:09 UTC  dat
 * 	New file for second XIDL drop for DCE 1.2.1
 * 	[1995/12/07  23:55:11  root]
 * 
 * Revision 1.1.2.1  1995/06/07  18:21:18  mccann
 * 	6/5/95 idl drop
 * 	[1995/06/07  18:21:05  mccann]
 * 
 * $EndLog$
 */
//
//  Copyright (c) Digital Equipment Corporation, 1995
//  All Rights Reserved.  Unpublished rights reserved
//  under the copyright laws of the United States.
//  
//  The software contained on this media is proprietary
//  to and embodies the confidential technology of 
//  Digital Equipment Corporation.  Possession, use,
//  duplication or dissemination of the software and
//  media is authorized only pursuant to a valid written
//  license from Digital Equipment Corporation.
//
//  RESTRICTED RIGHTS LEGEND   Use, duplication, or 
//  disclosure by the U.S. Government is subject to
//  restrictions as set forth in Subparagraph (c)(1)(ii)
//  of DFARS 252.227-7013, or in FAR 52.227-19, as
//  applicable.
//


