/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: comsoc_sys.h,v $
 * Revision 1.1.6.2  1996/02/18  23:46:52  marty
 * 	Update OSF copyright years
 * 	[1996/02/18  22:45:30  marty]
 *
 * Revision 1.1.6.1  1995/12/08  00:15:59  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/07  23:56:47  root]
 * 
 * Revision 1.1.4.3  1993/01/03  22:56:38  bbelch
 * 	Embedding copyright notice
 * 	[1993/01/03  19:56:11  bbelch]
 * 
 * Revision 1.1.4.2  1992/12/23  20:08:42  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/23  14:58:52  zeliff]
 * 
 * Revision 1.1.2.2  1992/05/01  16:04:24  rsalz
 * 	 10-mar-1992 pf      Initial revision
 * 	[1992/05/01  00:16:57  rsalz]
 * 
 * $EndLog$
 */
#include <../comsoc_bsd.h>
