/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: comsoc_sys.h,v $
 * Revision 1.1.6.2  1996/02/18  23:46:56  marty
 * 	Update OSF copyright years
 * 	[1996/02/18  22:45:33  marty]
 *
 * Revision 1.1.6.1  1995/12/08  00:16:05  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/07  23:56:50  root]
 * 
 * Revision 1.1.4.3  1993/01/03  22:56:41  bbelch
 * 	Embedding copyright notice
 * 	[1993/01/03  19:56:18  bbelch]
 * 
 * Revision 1.1.4.2  1992/12/23  20:08:56  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/23  14:59:12  zeliff]
 * 
 * Revision 1.1.2.2  1992/05/01  13:37:25  rsalz
 * 	 10-mar-1992 pf      Initial revision
 * 	[1992/04/30  22:49:13  rsalz]
 * 
 * $EndLog$
 */
#include <../comsoc_bsd.h>
