/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: comsoc_sys.h,v $
 * Revision 1.1.6.2  1996/02/18  22:55:15  marty
 * 	Update OSF copyright years
 * 	[1996/02/18  22:14:31  marty]
 *
 * Revision 1.1.6.1  1995/12/08  00:16:39  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/07  23:57:11  root]
 * 
 * Revision 1.1.4.3  1993/01/03  22:57:41  bbelch
 * 	Embedding copyright notice
 * 	[1993/01/03  19:57:59  bbelch]
 * 
 * Revision 1.1.4.2  1992/12/23  20:11:54  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/23  15:29:41  zeliff]
 * 
 * Revision 1.1.2.2  1992/05/01  16:05:08  rsalz
 * 	 10-mar-1992 pf      Initial revision
 * 	[1992/05/01  00:18:22  rsalz]
 * 
 * $EndLog$
 */
#include <../comsoc_bsd.h>
