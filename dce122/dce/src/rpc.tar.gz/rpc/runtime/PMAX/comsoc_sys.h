/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: comsoc_sys.h,v $
 * Revision 1.1.6.2  1996/02/18  22:55:08  marty
 * 	Update OSF copyright years
 * 	[1996/02/18  22:14:25  marty]
 *
 * Revision 1.1.6.1  1995/12/08  00:16:23  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/07  23:57:01  root]
 * 
 * Revision 1.1.4.3  1993/01/03  22:57:02  bbelch
 * 	Embedding copyright notice
 * 	[1993/01/03  19:56:55  bbelch]
 * 
 * Revision 1.1.4.2  1992/12/23  20:10:11  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/23  15:28:06  zeliff]
 * 
 * Revision 1.1.2.2  1992/05/01  16:04:53  rsalz
 * 	 10-mar-1992 pf      Initial revision
 * 	[1992/05/01  00:17:55  rsalz]
 * 
 * $EndLog$
 */
#include <../comsoc_bsd.h>
