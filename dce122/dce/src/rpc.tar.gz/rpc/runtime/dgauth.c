/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: dgauth.c,v $
 * Revision 1.1.601.2  1996/02/18  00:03:19  marty
 * 	Update OSF copyright years
 * 	[1996/02/17  22:55:52  marty]
 *
 * Revision 1.1.601.1  1995/12/08  00:19:18  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/07  23:58:44  root]
 * 
 * Revision 1.1.599.1  1994/01/21  22:36:21  cbrooks
 * 	RPC Code Cleanyp - Initial Submission
 * 	[1994/01/21  21:56:25  cbrooks]
 * 
 * Revision 1.1.4.3  1993/01/03  23:23:32  bbelch
 * 	Embedding copyright notice
 * 	[1993/01/03  20:04:05  bbelch]
 * 
 * Revision 1.1.4.2  1992/12/23  20:46:39  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/23  15:35:51  zeliff]
 * 
 * Revision 1.1.2.2  1992/05/01  17:20:14  rsalz
 * 	 08-nov-91 mishkin   obsolete
 * 	[1992/05/01  17:15:55  rsalz]
 * 
 * Revision 1.1  1992/01/19  03:06:13  devrcs
 * 	Initial revision
 * 
 * $EndLog$
 */
/*
**  Copyright (c) 1989 by
**      Hewlett-Packard Company, Palo Alto, Ca. & 
**      Digital Equipment Corporation, Maynard, Mass.
**
**
**  NAME
**
**      dgauth.c
**
**  FACILITY:
**
**      Remote Procedure Call (RPC) 
**
**  ABSTRACT:
**
**  Maintain registry of known authtypes.
**
**
*/

#error This file is obsolete
