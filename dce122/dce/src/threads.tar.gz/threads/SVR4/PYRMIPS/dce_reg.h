/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1994, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * (c) Copyright 1991, 1992 Siemens-Nixdorf Information Systems
 * Burlington, MA, USA
 * All Rights Reserved
 * (c) Copyright 1990, 1991, 1992
 */
/*
 * HISTORY
 * $Log: dce_reg.h,v $
 * Revision 1.1.8.2  1996/02/18  23:08:49  marty
 * 	Update OSF copyright years
 * 	[1996/02/18  22:32:25  marty]
 *
 * Revision 1.1.8.1  1995/12/07  21:52:54  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/07  21:02:07  root]
 * 
 * Revision 1.1.6.1  1994/06/09  13:36:11  devsrc
 * 	 CR10892 - fix copyright in file
 * 	[1994/06/09  13:26:35  devsrc]
 * 
 * Revision 1.1.3.3  1992/12/15  22:24:00  alan
 * 	Insert copyright notices
 * 	[1992/12/07  16:08:12  alan]
 * 
 * Revision 1.1.3.2  1992/09/29  21:26:01  devsrc
 * 	[OT 5373]    SNI/SVR4 merge.
 * 	[1992/09/17  20:39:25  sekhar]
 * 
 * $EndLog$
 */

#ifdef SNI_SVR4_TAINTED
#endif	/* SNI_SVR4_TAINTED */
