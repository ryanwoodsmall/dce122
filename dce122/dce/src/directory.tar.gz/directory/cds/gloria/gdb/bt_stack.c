/* ______________________________________________________________________ */
/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1993 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: bt_stack.c,v $
 * Revision 1.1.2.1  1996/10/03  20:22:23  arvind
 * 	OSF DCE 1.2.2 Drop 4
 * 	[1996/10/03  19:17:32  arvind]
 *
 * 	OSF DCE 1.2.2 Drop 4
 *
 * Revision /main/DCE_1.2.2/1  1996/09/09  21:21 UTC  arvind
 * 	PKSS drop from DEC (DCE1.2.2)
 * 	[1996/08/30  15:36 UTC  arvind  /main/arvind_pkss/1]
 * 
 * 	Multiple updates per code review
 * 	[1996/05/14  22:51:10  sweeney]
 * 	 *
 * 
 * 	Initial modifications for GLORIA and use of GDB database interface
 * 	[1995/06/27  17:59:52  farrell]
 * 
 * 	Initial modifications for GLORIA and use of GDB database interface
 * 	[1995/06/27  17:50:20  farrell]
 * 
 * 	Obsolete.  No longer in version 1.85 of db44.
 * 	[1995/03/03  20:05:28  zee]
 * 
 * 	DCE for DEC OSF/1: populate from OSF DCE R1.1
 * 	[1995/03/03  18:45:46  zee]
 * 
 * 	Initial checkin.
 * 	[1993/12/01  16:54:39  bowe]
 * 
 * $EndLog$
 */
/* ______________________________________________________________________ */
