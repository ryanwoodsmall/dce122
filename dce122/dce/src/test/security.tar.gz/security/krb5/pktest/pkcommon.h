/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: pkcommon.h,v $
 * Revision 1.1.2.1  1996/10/03  20:37:40  arvind
 * 	OSF DCE 1.2.2 Drop 4
 * 	[1996/10/03  19:46:03  arvind]
 *
 * 	OSF DCE 1.2.2 Drop 4
 *
 * Revision /main/DCE_1.2.2/1  1996/09/26  23:32 UTC  sommerfeld
 * 	a few prototypes..
 * 
 * $EndLog$
 */
void test_dump_data(sec_pk_data_t *d);
int test_load_data(sec_pk_data_t *dload);


