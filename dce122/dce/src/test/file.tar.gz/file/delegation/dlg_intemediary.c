/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * 
 */
/*
 * HISTORY
 * $Log: dlg_intemediary.c,v $
 * Revision 1.1.8.1  1996/10/17  18:18:55  damon
 * 	Submitting on behalf of Transarc
 * 	[1996/10/17  16:50:19  damon]
 *
 * Revision 1.1.3.2  1994/08/10  19:23:07  annie
 * 	expand copyright with OSF copyright text
 * 	[1994/08/10  17:17:23  annie]
 * 
 * Revision 1.1.3.1  1994/07/13  22:33:07  devsrc
 * 	merged with bl-10
 * 	[1994/06/29  12:17:46  devsrc]
 * 
 * 	Delegation Functional Tests - Initial Submit
 * 	[1994/06/08  18:30:26  delgado]
 * 
 * $EndLog$
 */
