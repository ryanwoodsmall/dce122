# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
# src directory for the full copyright text.
#
# HISTORY
# $Log: simple08.rs,v $
# Revision 1.1.8.1  1996/10/17  18:34:29  damon
# 	Submitting on behalf of Transarc
# 	[1996/10/17  16:57:08  damon]
#
# Revision 1.1.3.1  1994/07/13  22:32:13  devsrc
# 	merged with bl-10
# 	[1994/06/29  12:15:44  devsrc]
# 
# 	moving files from src/file/episode to test/file
# 	[1994/03/22  20:40:38  delgado]
# 
# 	embedded copyright notice
# 	[1993/01/19  13:53:55  cjd]
# 
# 	New file
# 	[1992/11/17  20:57:10  jaffe]
# 
# $EndLog$

create foo bar
createfiles 10 foobar
rm bar foo
rmfiles 5 foobar
