
# use up too three machines
# should agree with cellconfig.data

M1=testlab-7-203
M2=galileo
M3=testlab-7-203

CELL_ADMIN=cell_admin
CELL_ADMIN_PASSWD=-dce-

# need full path names

SRC_DIR=/:/EPI_HOME/TEST/delegation.system
TOP_DIR=/:/EPI_HOME/TEST/delegation.system

# LFS directory where files created by test go.

LFS_DIR=/:

# set this flag to run the dcp setup script

SETUP=1

# set to run tests

RUN_FILE_TEST=1
RUN_DIR_TEST=1
RUN_CHAIN_TEST=1
