package main;

# IMPORTANT:
# Change length of the following basic types if they differ on
# machine of choice.

$LEN_INT = 4;
