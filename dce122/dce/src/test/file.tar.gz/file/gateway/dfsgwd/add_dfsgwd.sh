#!/bin/sh
#
# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
# the full copyright text.
#
# HISTORY
# $Log: add_dfsgwd.sh,v $
# Revision 1.1.6.1  1996/10/17  18:23:57  damon
# 	Submitting on behalf of Transarc
# 	[1996/10/17  16:52:11  damon]
#
# Revision 1.1.2.2  1994/10/06  20:29:58  agd
# 	expand copyright
# 	[1994/10/06  14:28:06  agd]
# 
# Revision 1.1.2.1  1994/08/22  16:16:33  maunsell_c
# 	use dfs_config when its ready
# 	[1994/08/10  19:01:45  maunsell_c]
# 
# $EndLog$
#
#

#
#

exit 0

