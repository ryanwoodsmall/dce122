#
# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
# the full copyright text.
#
# HISTORY
# $Log: rem_dfsgwd.sh,v $
# Revision 1.1.6.1  1996/10/17  18:23:59  damon
# 	Submitting on behalf of Transarc
# 	[1996/10/17  16:52:13  damon]
#
# Revision 1.1.2.2  1994/10/06  20:30:11  agd
# 	expand copyright
# 	[1994/10/06  14:28:10  agd]
# 
# Revision 1.1.2.1  1994/08/22  16:16:34  maunsell_c
# 	use dfs_unconfig when its available
# 	[1994/08/10  19:05:16  maunsell_c]
# 
# $EndLog$
#
#

#
#

exit 0
