'''	SCCS: @(#) DTET SPECIFICATION		Rel 1.2 (9/15/92)
.de )k
..
.PH ""
.PF ""
.ds HP +3 +2 +2 +1 +1 +0 +0
.ds HF 3 3 3 3 3 3 3
.nr Hs 7
.nr Hb 7
.nr Cl 7
.nr Ej 1
.S 12
.DS C
.S +3
.SP 7
.B
Distributed Test Environment Toolkit
.SP
Architectural, Functional, and Interface Specification
.SP 2
.R
.S -3
This document is written as a series of changes and additions to the
.SP 2
.S +2
.I
Test Environment Toolkit
.SP
Architecture, Functional, and Interface Specification
.R
.S -2
.SP 20
Revision 1.2
.SP
\*(DT
.R
.DE
.PH "'\s12Distributed Test Environment Toolkit Specification'''"
.bp
.PF "'Revision 1.2'\s12Page \\\\nP'\*(DT"
