'\"	SCCS: @(#) TET SPECIFICATION		Rel 4.5 (06/23/92)
'\"
.nr H1 0
.nr Ej 1
.HM A 1 1 1 1 1 1
.HU "Appendix A - Contacts"
The following constitute the Management Committee of the Project:
.sp
.DS
Open Software Foundation

John Morris
Director, Software Engineering
Open Software Foundation
11 Cambridge Center
Cambridge, MA 02142  USA

+1 617-621-8739
+1 617-225-2782 (fax)
jsm@osf.org

UNIX International

Shane McCarron
Project Manager, Technology and Product Planning
UNIX International
20 Waterview Blvd.
Parsippany, NJ 07054  USA

+1 201-263-8400x232
+1 201-263-8401 (fax)
mccarron@uiunix.ui.org

X/Open

James de Raeve
Conformance Strategy Manager
X/Open Company, Ltd.
Apex Plaza
Forbury Road
Reading RG1 1AX
Berkshire  ENGLAND

+44 (0) 734 508311
+44 (0) 734 500110 (fax)
j.deraeve@xopen.co.uk
.DE
