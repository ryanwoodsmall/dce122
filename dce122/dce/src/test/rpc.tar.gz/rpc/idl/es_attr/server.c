/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: server.c,v $
 * Revision 1.1.4.2  1996/02/17  23:14:06  marty
 * 	Update OSF copyright year
 * 	[1996/02/17  22:34:40  marty]
 *
 * Revision 1.1.4.1  1995/12/11  20:05:09  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:31:14  root]
 * 
 * Revision 1.1.2.1  1994/05/10  18:03:35  tom
 * 	Test for ecoding services get/set attribute.
 * 	[1994/05/10  16:02:54  tom]
 * 
 * $EndLog$
 */

main()
{
    /*
     * Sleep forever 
     */
    while (1)
        ;
    exit (0);
}
