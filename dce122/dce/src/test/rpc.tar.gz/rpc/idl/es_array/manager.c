/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: manager.c,v $
 * Revision 1.1.4.2  1996/02/17  23:13:55  marty
 * 	Update OSF copyright year
 * 	[1996/02/17  22:34:34  marty]
 *
 * Revision 1.1.4.1  1995/12/11  20:03:58  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:30:47  root]
 * 
 * Revision 1.1.2.2  1993/08/11  16:24:01  ganni
 * 	tests for new IDL functionality
 * 	[1993/08/11  16:13:12  ganni]
 * 
 * $EndLog$
 */
/*
*/

#include <stdio.h>
#include <es_array.h>
#include <test_common.h>

/*globaldef*/ es_array_v0_0_epv_t es_array_v0_0_m_epv;

