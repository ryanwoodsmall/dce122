/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: manager.c,v $
 * Revision 1.1.4.2  1996/02/17  23:14:02  marty
 * 	Update OSF copyright year
 * 	[1996/02/17  22:34:38  marty]
 *
 * Revision 1.1.4.1  1995/12/11  20:04:41  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:31:02  root]
 * 
 * Revision 1.1.2.2  1993/08/11  16:25:32  ganni
 * 	tests for new IDL functionality
 * 	[1993/08/11  16:13:57  ganni]
 * 
 * $EndLog$
 */
/*
*/

#include <stdio.h>
#include <es_arrayc.h>
#include <test_common.h>

/*globaldef*/ es_arrayc_v0_0_epv_t es_arrayc_v0_0_m_epv;

