/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: manager.c,v $
 * Revision 1.1.4.2  1996/02/17  23:13:58  marty
 * 	Update OSF copyright year
 * 	[1996/02/17  22:34:35  marty]
 *
 * Revision 1.1.4.1  1995/12/11  20:04:15  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:30:55  root]
 * 
 * Revision 1.1.2.2  1993/08/11  16:24:41  ganni
 * 	tests for new IDL functionality
 * 	[1993/08/11  16:13:29  ganni]
 * 
 * $EndLog$
 */
/*
*/

#include <stdio.h>
#include <es_arrayb.h>
#include <test_common.h>

/*globaldef*/ es_arrayb_v0_0_epv_t es_arrayb_v0_0_m_epv;

