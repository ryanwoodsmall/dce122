/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * 
 */
/*
 * HISTORY
 * $Log: objectid.h,v $
 * Revision 1.1.2.2  1996/03/09  20:49:49  marty
 * 	Add OSF copyright
 * 	[1996/03/09  20:28:08  marty]
 *
 * Revision 1.1.2.1  1995/12/11  19:35:41  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:18:45  root]
 * 
 * $EndLog$
 */
#define DCE_OBJECTID "73999660-e506-11cd-aa90-08002b3d8412"
