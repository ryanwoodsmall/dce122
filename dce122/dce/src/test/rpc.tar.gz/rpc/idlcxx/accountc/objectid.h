/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 */

/*
 * HISTORY
 * $Log: objectid.h,v $
 * Revision 1.1.2.3  1996/03/09  20:48:15  marty
 * 	Add OSF copyright
 * 	[1996/03/09  20:26:55  marty]
 *
 * Revision 1.1.2.2  1996/02/07  17:48:23  parul
 * 	DCE 1.2.1 final drop from HP
 * 	[1996/02/07  16:14:08  parul]
 * 
 * 	DCE 1.2.1 final drop from HP
 * 
 * 	HP revision /main/DCE_1.2/2  1996/01/30  16:05 UTC  psn
 * 	Fix comment leaders.
 * 
 * 	HP revision /main/DCE_1.2/1  1996/01/03  20:36 UTC  psn
 * 	HP DCE 1.2.2 Initial
 * 
 * $EndLog$
 */

#define DCE_OBJECTID "3895b94e-f7d6-11cd-8e0f-08002b3d8412"
