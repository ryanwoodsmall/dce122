/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * 
 */
/*
 * HISTORY
 * $Log: objectid.h,v $
 * Revision 1.1.2.2  1996/03/09  20:47:51  marty
 * 	Add OSF copyright
 * 	[1996/03/09  20:26:38  marty]
 *
 * Revision 1.1.2.1  1995/12/11  19:32:59  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:17:20  root]
 * 
 * $EndLog$
 */
#define DCE_OBJECTID "3895b94e-f7d6-11cd-8e0f-08002b3d8412"
