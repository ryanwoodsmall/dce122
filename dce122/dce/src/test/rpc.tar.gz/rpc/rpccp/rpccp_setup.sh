if1=d5c89800-6dae-11c9-a1c1-08002b102989.0000.0000
#
# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
# src directory for the full copyright text.
#
#
# HISTORY
# $Log: rpccp_setup.sh,v $
# Revision 1.1.4.2  1996/03/11  02:20:40  marty
# 	Update OSF copyright years
# 	[1996/03/10  19:56:38  marty]
#
# Revision 1.1.4.1  1995/12/11  19:36:31  root
# 	Submit OSF/DCE 1.2.1
# 	[1995/12/11  19:19:13  root]
# 
# Revision 1.1.2.2  1993/01/11  21:15:19  bbelch
# 	Embedding copyright notice
# 	[1993/01/06  14:55:54  bbelch]
# 
# Revision 1.1  1992/01/19  03:41:13  devrcs
# 	Initial revision
# 
# $EndLog$
#
if2=e9eb0340-6dae-11c9-823d-08002b102989.0000.0000
if21=e9eb0340-6dae-11c9-823d-08002b102989.0001.0000
if10=d5c89800-6dae-11c9-a1c1-08002b102989.0001.0000
if11=d5c89800-6dae-11c9-a1c1-08002b102989.0001.0001
if12=d5c89800-6dae-11c9-a1c1-08002b102989.0001.0002
if20=d5c89800-6dae-11c9-a1c1-08002b102989.0002.0000
if30=d5c89800-6dae-11c9-a1c1-08002b102989.0003.0000
obj1=fbe696e0-6dae-11c9-b093-08002b102989
obj2=02d52fc0-6daf-11c9-b958-08002b102989
b1=ncadg_ip_udp:127.0.0.1[1234]
b2=ncacn_ip_tcp:127.0.0.1[3000]
b3=ncadg_ip_udp:127.0.0.1[2000]
b4=ncacn_ip_tcp:127.0.0.1[1000]
