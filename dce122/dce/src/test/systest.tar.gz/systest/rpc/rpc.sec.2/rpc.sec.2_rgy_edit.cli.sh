# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
# src directory for the full copyright text.
#
# HISTORY
# $Log: rpc.sec.2_rgy_edit.cli.sh,v $
# Revision 1.1.39.2  1996/03/11  02:46:39  marty
# 	Update OSF copyright years
# 	[1996/03/10  20:08:25  marty]
#
# Revision 1.1.39.1  1995/12/11  22:43:59  root
# 	Submit OSF/DCE 1.2.1
# 	[1995/12/11  22:20:41  root]
# 
# Revision 1.1.37.1  1993/09/09  19:12:56  cmckeen
# 	 HP's TET'ized version
# 	[1993/09/09  19:11:53  cmckeen]
# 
# Revision 1.1.2.2  1993/08/16  14:34:06  eheller
# 	Initial release.
# 	[1993/07/23  18:02:14  eheller]
# 
# $EndLog$
#
do account
change -p rpc.sec.2_cli















y
5m

y

q
