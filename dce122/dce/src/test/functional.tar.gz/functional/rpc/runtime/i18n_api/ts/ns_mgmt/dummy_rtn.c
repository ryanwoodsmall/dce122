/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1994, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * 
 */
/*
 * HISTORY
 * $Log: dummy_rtn.c,v $
 * Revision 1.1.4.2  1996/02/18  00:34:01  marty
 * 	Update OSF copyright years
 * 	[1996/02/17  23:19:16  marty]
 *
 * Revision 1.1.4.1  1995/12/11  19:51:51  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  19:26:34  root]
 * 
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/11  18:17:58  root]
 * 
 * Revision 1.1.2.2  1994/06/10  20:44:24  devsrc
 * 	cr10872 - fixed copyright
 * 	[1994/06/10  17:16:14  devsrc]
 * 
 * Revision 1.1.2.1  1994/05/04  21:54:49  mori_m
 * 	CR 9701: RPC runtime I18N extension functional test drop.
 * 	[1994/05/04  21:17:34  mori_m]
 * 
 * $EndLog$
 */

#include "dummy_if.h"

void sum_arrays (
	long_array a,
	long_array b
)
{
 ;
}
