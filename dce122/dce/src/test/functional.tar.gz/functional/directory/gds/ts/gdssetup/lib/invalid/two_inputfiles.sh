# 
# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994, 1996 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for 
# the full copyright text.
#
# 
# HISTORY
# $Log: two_inputfiles.sh,v $
# Revision 1.1.4.2  1996/03/11  01:35:19  marty
# 	Update copyright years
# 	[1996/03/10  19:37:41  marty]
#
# Revision 1.1.4.1  1995/12/11  15:30:07  root
# 	Submit
# 	[1995/12/11  14:37:58  root]
# 
# Revision 1.1.2.1  1994/08/19  13:54:40  marrek
# 	Improvement in test code coverage (ot11586).
# 	[1994/08/10  13:09:51  marrek]
# 
# $EndLog$
#
# $RCSfile: two_inputfiles.sh,v $ $Revision: 1.1.4.2 $ $Date: 1996/03/11 01:35:19 $
#

#Two input files for GDSSETUP

gdssetup xxx1 xxx2
