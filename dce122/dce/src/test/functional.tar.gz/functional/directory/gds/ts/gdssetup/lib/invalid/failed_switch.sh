# 
# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994, 1996 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for 
# the full copyright text.
#
# 
# HISTORY
# $Log: failed_switch.sh,v $
# Revision 1.1.4.2  1996/03/11  01:34:36  marty
# 	Update copyright years
# 	[1996/03/10  19:36:46  marty]
#
# Revision 1.1.4.1  1995/12/11  15:28:45  root
# 	Submit
# 	[1995/12/11  14:37:17  root]
# 
# Revision 1.1.2.1  1994/08/19  13:54:22  marrek
# 	Improvement in test code coverage (ot11586).
# 	[1994/08/10  13:09:43  marrek]
# 
# $EndLog$
#
# $RCSfile: failed_switch.sh,v $ $Revision: 1.1.4.2 $ $Date: 1996/03/11 01:34:36 $
#

#The input switch is not right

gdssetup -aaa
