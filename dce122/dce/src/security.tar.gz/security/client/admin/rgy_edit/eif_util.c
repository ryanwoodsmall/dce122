/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: eif_util.c,v $
 * Revision 1.1.4.2  1996/03/11  13:26:46  marty
 * 	Update OSF copyright years
 * 	[1996/03/11  13:14:44  marty]
 *
 * Revision 1.1.4.1  1995/12/08  17:59:05  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/08  16:29:56  root]
 * 
 * Revision 1.1.2.2  1992/12/29  12:39:33  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/28  20:12:08  zeliff]
 * 
 * Revision 1.1  1992/01/19  14:46:16  devrcs
 * 	Initial revision
 * 
 * $EndLog$
 */
/*
*/

/*  eif_util.c V=11 11/22/91 //littl/prgy/src/edrgy
**
** Copyright (c) Hewlett-Packard Company 1991
** Unpublished work. All Rights Reserved.
**
*/
/*
**      rgy_edit generic interface utilities
** 
*/

#ifdef MODULE_VERSION_ID
static char *VersionID = "@(#)eif_util.c	11 - 11/22/91";
#endif

#error THIS MODULE IS OBSOLETE
