/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE in the
 * src directory for the full copyright text.
 */
/*
 * HISTORY
 * $Log: copyright.h,v $
 * Revision 1.1.4.2  1996/02/18  23:02:13  marty
 * 	Update OSF copyright years
 * 	[1996/02/18  22:20:39  marty]
 *
 * Revision 1.1.4.1  1995/12/08  17:41:29  root
 * 	Submit OSF/DCE 1.2.1
 * 	[1995/12/08  16:56:55  root]
 * 
 * Revision 1.1.2.2  1992/12/29  13:58:13  zeliff
 * 	Embedding copyright notice
 * 	[1992/12/28  20:51:56  zeliff]
 * 
 * Revision 1.1  1992/01/19  14:48:09  devrcs
 * 	Initial revision
 * 
 * $EndLog$
 */
/*
*/

/*  copyright.h V=2 08/24/90 //littl/prgy/krb5/include/krb5
**
** Copyright (c) Hewlett-Packard Company 1991
** Unpublished work. All Rights Reserved.
**
*/
/*
 * Copyright (C) 1989, 1990 by the Massachusetts Institute of Technology,
 * Cambridge, MA, USA.  All Rights Reserved.
 *
 * Project Athena, Athena, Athena MUSE, Discuss, Hesiod, Kerberos,
 * Moira, and Zephyr are trademarks of the Massachusetts Institute of
 * Technology (MIT).  No commercial use of these trademarks may be made
 * without prior written permission of MIT.
 */
