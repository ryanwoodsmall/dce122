/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1994, 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * All Rights Reserved
 */
/*
 * HISTORY
 * $Log: kdc_util.h,v $
 * Revision 1.1.6.1  1996/10/03  14:50:11  arvind
 * 	OSF DCE 1.2.2 Drop 4
 * 	[1996/10/03  14:10:22  arvind]
 *
 * $EndLog$
 */
#error This file is obsolete. See ../../krb5/kdc/kdc_util.h instead.
