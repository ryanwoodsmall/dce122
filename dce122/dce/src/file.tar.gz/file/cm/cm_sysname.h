/* Copyright (c) Transarc Corporation  All Rights Reserved */

#define CM_MAXSYSNAME           128     /* max sysname (i.e. @sys) size */

