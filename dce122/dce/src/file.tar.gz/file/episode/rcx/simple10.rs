# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
# the full copyright text.
#
# HISTORY
# $Log: simple10.rs,v $
# Revision 1.1.11.1  1996/10/02  17:27:03  damon
# 	Newest DFS from Transarc
# 	[1996/10/01  18:33:41  damon]
#
# Revision 1.1.6.1  1994/06/09  14:02:47  annie
# 	fixed copyright in src/file
# 	[1994/06/08  21:37:47  annie]
# 
# Revision 1.1.2.3  1993/01/19  15:32:16  cjd
# 	embedded copyright notice
# 	[1993/01/19  13:54:03  cjd]
# 
# Revision 1.1.2.2  1992/11/18  19:21:18  jaffe
# 	New file
# 	[1992/11/17  20:59:43  jaffe]
# 
# $EndLog$

create bar
mkdir foo
mv bar rab
mv foo oof
createfiles 10 gigo
mvpaths 5 gigo fifo
