# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
# the full copyright text.
#
# HISTORY
# $Log: simple14.rs,v $
# Revision 1.1.11.1  1996/10/02  17:27:07  damon
# 	Newest DFS from Transarc
# 	[1996/10/01  18:33:48  damon]
#
# Revision 1.1.6.1  1994/06/09  14:02:50  annie
# 	fixed copyright in src/file
# 	[1994/06/08  21:37:50  annie]
# 
# Revision 1.1.2.3  1993/01/19  15:32:26  cjd
# 	embedded copyright notice
# 	[1993/01/19  13:54:20  cjd]
# 
# Revision 1.1.2.2  1992/11/18  19:30:29  jaffe
# 	New file
# 	[1992/11/17  21:03:48  jaffe]
# 
# $EndLog$

create c 
write b 10 0 0 c

 

 
