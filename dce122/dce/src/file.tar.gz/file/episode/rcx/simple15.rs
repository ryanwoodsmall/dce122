# @OSF_COPYRIGHT@
# COPYRIGHT NOTICE
# Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
# ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
# the full copyright text.
#
# HISTORY
# $Log: simple15.rs,v $
# Revision 1.1.11.1  1996/10/02  17:27:09  damon
# 	Newest DFS from Transarc
# 	[1996/10/01  18:33:49  damon]
#
# Revision 1.1.6.1  1994/06/09  14:02:51  annie
# 	fixed copyright in src/file
# 	[1994/06/08  21:37:52  annie]
# 
# Revision 1.1.2.3  1993/01/19  15:32:29  cjd
# 	embedded copyright notice
# 	[1993/01/19  13:54:24  cjd]
# 
# Revision 1.1.2.2  1992/11/18  19:30:36  jaffe
# 	New file
# 	[1992/11/17  21:04:52  jaffe]
# 
# $EndLog$

createfiles 5 c 
writefiles 5 b 2 0 0 1 c
