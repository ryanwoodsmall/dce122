/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1990, 1991, 1992, 1993, 1994 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 */
/*
 * HISTORY
 * $Log: gtxinput.h,v $
 * Revision 1.1.9.1  1996/10/02  17:51:03  damon
 * 	Newest DFS from Transarc
 * 	[1996/10/01  18:39:59  damon]
 *
 * Revision 1.1.4.1  1994/06/09  14:09:57  annie
 * 	fixed copyright in src/file
 * 	[1994/06/09  13:24:33  annie]
 * 
 * Revision 1.1.2.2  1993/01/19  16:02:52  cjd
 * 	embedded copyright notice
 * 	[1993/01/19  14:12:44  cjd]
 * 
 * Revision 1.1  1992/01/19  02:41:18  devrcs
 * 	Initial revision
 * 
 * $EndLog$
 */
/*
*/
/* Input structure  */
