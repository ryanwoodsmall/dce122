/*
 * @OSF_COPYRIGHT@
 * COPYRIGHT NOTICE
 * Copyright (c) 1996 Open Software Foundation, Inc.
 * ALL RIGHTS RESERVED (DCE).  See the file named COPYRIGHT.DCE for
 * the full copyright text.
 * All Rights Reserved
 */
#include <stdio.h>

void real0(int a, int b, int c) 
{
    if (a != 0) abort();
    printf("real0: %d %d %d\n", a, b, c);
}
void real1(int a, int b, int c) 
{
    if (a != 1) abort();
    printf("real1: %d %d %d\n", a, b, c);
}
void real2(int a, int b, int c) 
{
    if (a != 2) abort();
    printf("real2: %d %d %d\n", a, b, c);
}
void real3(int a, int b, int c) 
{
    if (a != 3) abort();
    printf("real3: %d %d %d\n", a, b, c);
}
void real4(int a, int b, int c) 
{
    if (a != 4) abort();
    printf("real4: %d %d %d\n", a, b, c);
}
void real5(int a, int b, int c) 
{
    if (a != 5) abort();
    printf("real5: %d %d %d\n", a, b, c);
}
void real6(int a, int b, int c) 
{
    if (a != 6) abort();
    printf("real6: %d %d %d\n", a, b, c);
}
void real7(int a, int b, int c) 
{
    if (a != 7) abort();
    printf("real7: %d %d %d\n", a, b, c);
}
void real8(int a, int b, int c) 
{
    if (a != 8) abort();
    printf("real8: %d %d %d\n", a, b, c);
}
void real9(int a, int b, int c) 
{
    if (a != 9) abort();
    printf("real9: %d %d %d\n", a, b, c);
}
void real10(int a, int b, int c) 
{
    if (a != 10) abort();
    printf("real10: %d %d %d\n", a, b, c);
}
void real11(int a, int b, int c) 
{
    if (a != 11) abort();
    printf("real11: %d %d %d\n", a, b, c);
}
void real12(int a, int b, int c) 
{
    if (a != 12) abort();
    printf("real12: %d %d %d\n", a, b, c);
}
void real13(int a, int b, int c) 
{
    if (a != 13) abort();
    printf("real13: %d %d %d\n", a, b, c);
}
void real14(int a, int b, int c) 
{
    if (a != 14) abort();
    printf("real14: %d %d %d\n", a, b, c);
}
void real15(int a, int b, int c) 
{
    if (a != 15) abort();
    printf("real15: %d %d %d\n", a, b, c);
}
void real16(int a, int b, int c) 
{
    if (a != 16) abort();
    printf("real16: %d %d %d\n", a, b, c);
}
void real17(int a, int b, int c) 
{
    if (a != 17) abort();
    printf("real17: %d %d %d\n", a, b, c);
}
void real18(int a, int b, int c) 
{
    if (a != 18) abort();
    printf("real18: %d %d %d\n", a, b, c);
}
void real19(int a, int b, int c) 
{
    if (a != 19) abort();
    printf("real19: %d %d %d\n", a, b, c);
}
void real20(int a, int b, int c) 
{
    if (a != 20) abort();
    printf("real20: %d %d %d\n", a, b, c);
}
void real21(int a, int b, int c) 
{
    if (a != 21) abort();
    printf("real21: %d %d %d\n", a, b, c);
}
void real22(int a, int b, int c) 
{
    if (a != 22) abort();
    printf("real22: %d %d %d\n", a, b, c);
}
void real23(int a, int b, int c) 
{
    if (a != 23) abort();
    printf("real23: %d %d %d\n", a, b, c);
}
void real24(int a, int b, int c) 
{
    if (a != 24) abort();
    printf("real24: %d %d %d\n", a, b, c);
}
void real25(int a, int b, int c) 
{
    if (a != 25) abort();
    printf("real25: %d %d %d\n", a, b, c);
}
void real26(int a, int b, int c) 
{
    if (a != 26) abort();
    printf("real26: %d %d %d\n", a, b, c);
}
void real27(int a, int b, int c) 
{
    if (a != 27) abort();
    printf("real27: %d %d %d\n", a, b, c);
}
void real28(int a, int b, int c) 
{
    if (a != 28) abort();
    printf("real28: %d %d %d\n", a, b, c);
}
void real29(int a, int b, int c) 
{
    if (a != 29) abort();
    printf("real29: %d %d %d\n", a, b, c);
}
void real30(int a, int b, int c) 
{
    if (a != 30) abort();
    printf("real30: %d %d %d\n", a, b, c);
}
void real31(int a, int b, int c) 
{
    if (a != 31) abort();
    printf("real31: %d %d %d\n", a, b, c);
}

